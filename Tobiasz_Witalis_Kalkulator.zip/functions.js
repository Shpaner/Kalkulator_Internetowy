// autor Tobiasz Witalis

const signsArray = ['/', '*', '-', '+']
var previuosSign = '/'

function addValue(val) {
	console.log(previuosSign)

	for (var i = 0; i < signsArray.length; i++)  {
		if (signsArray[i] == val) {

			// change color of previously clicked sign
			document.getElementById(previuosSign).style.color = "#FFF"
			document.getElementById(previuosSign).style.backgroundColor = "#0c2835"

			//change color of the chosen sign
			document.getElementById(val).style.color = "#111"
			document.getElementById(val).style.backgroundColor = "#0091ea"

			previuosSign = val
		}
	}
}


function openSpec() {

	var i, x
	x = document.getElementById("hidden_spec")

	console.log(x.style.display)

	if (x.style.display == "none") {
		document.getElementById("hidden_spec").style.display = "block";
	} else {
		document.getElementById("hidden_spec").style.display = "none";
	}
}